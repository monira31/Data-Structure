#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
    char foodname[1000];
    int quantity;
    float price;
    int data;
    struct node *prev;
    struct node *next;
};

struct node *headc = NULL,*newnode,*tailc = NULL;
struct node *heada = NULL, *taila = NULL;
struct node *head_s;

void adminmenu()
{
    printf("\n\t\t\t\t\t\t\t1. View total reservations\n");
    printf("\t\t\t\t\t\t\t2. Add new deal or special offer in the lunch/dinner menu\n");
    printf("\t\t\t\t\t\t3. Delete existing deal or special offer from the lunch/dinner menu\n");
    printf("\t\t\t\t\t\t\t4. Display existing schedule and deal\n");
    printf("\t\t\t\t\t\t\t5. Back To Main Menu \n\n");
    printf("\t\t\t\t\t\t\t   Enter Your Choice --->");
}

void customermenu()
{
    printf("\n\t\t\t\t\t\t\t1. Place your order\n");
    printf("\t\t\t\t\t\t\t2. View entire menu\n");
    printf("\t\t\t\t\t\t\t3. Display newly added item\n");
    printf("\t\t\t\t\t\t\t4.Help and Complain \n");
    printf("\t\t\t\t\t\t\t5. Back To Main Menu \n\n");


}
void lunch()
{
    printf("\n\n\n\t\t\t\t Menu for LUNCH : \n");
    printf("\t\t\t      ^^^^^^^^^^^^^^^^^^^^^^ \n");
    printf("\n\t\t\t\t 1. Salad section :- \n\n\t\t\t\t a.Green Salad\n\t\t\t\t b.Vegatbale salad \n\t\t\t\t c.Cashew nut salad \n");
    printf("\n\t\t\t\t 2. Soup section :- \n\n\t\t\t\t a.Thai soup \n\t\t\t\t b.Corn soup \n\t\t\t\t c.Cream and mushroom \n");
    printf("\n\t\t\t\t 3. Sides :- \n\n\t\t\t\t a.Wonton \n\t\t\t\t b.French fries \n\t\t\t\t c.Chicken fingers\n\t\t\t\t d.Mashed Potato\n\t\t\t\t e.Sweet Corn\n\t\t\t\t f.Colslaw \n");
    printf("\n\t\t\t\t 4. Rice section :- \n\n\t\t\t\t a.Fried rice \n\t\t\t\t b.Beef Biriyani \n\t\t\t\t c.Mutton Kacchi \n\t\t\t\t d.Chicken Biriyani \n\t\t\t\t e.Khichuri \n\t\t\t\t f.Plain Rice \n\t\t\t\t g.Steamed Rice \n");
    printf("\n\t\t\t\t 5. Naan section :-\n\n\t\t\t\t a.Normal Naan \n\t\t\t\t b.Garlic Butter Naan\n\t\t\t\t c.Keema Naan\n\t\t\t\t d.Spicy Naan\n\t\t\t\t e.Rumali Ruti\n");
    printf("\n\t\t\t\t 6. Chicken section :- \n\n\t\t\t\t a.Chicken Fry \n\t\t\t\t b.Chili Chicken\n\t\t\t\t c.Butter Chicken\n\t\t\t\t d.Chicken Green Curry\n\t\t\t\t e.Chicken Tikka Masala\n\t\t\t\t f.Munchurian\n");
    printf("\n\t\t\t\t 7. Beef section :- \n\n\t\t\t\t a.Kala Bhuna \n\t\t\t\t b.Beef Curry\n\t\t\t\t c.Beef Hatkora\n\t\t\t\t d.Bulgogi\n\t\t\t\t e.Roast Beef\n");
    printf("\n\t\t\t\t 8. Fish section :-\n\n\t\t\t\t a.Prawn Curry \n\t\t\t\t b.Lemon paper fish\n\t\t\t\t c.Prawn Malaikari\n\t\t\t\t d.Rupchanda Fry\n\t\t\t\t e.Rui dopiaza\n");
    printf("\n\t\t\t\t 9. Kabab and grill section :- \n\n\t\t\t\ta.Reshmi Chicken Kabab\n\t\t\t\t b.Chicken Chap\n\t\t\t\t c.Beef Boti Kabab\n\t\t\t\t d.Charcol Grill Kabab\n\t\t\t\t e.Tandoori Kabab\n");
    printf("\n\t\t\t\t 11. Steak section :- \n\n\t\t\t\t a.Chicken Steak\n\t\t\t\t b.Brisket\n\t\t\t\t c.Ribeye\n\t\t\t\t d.T- Bone steak\n");
    printf("\n\t\t\t\t 12. Vegetable section :-\n\n\t\t\t\t a.Sauteed Vegetable\n\t\t\t\t b.Stir Fry Vegetable\n\t\t\t\t c.chinese Mixed Vegetable\n\t\t\t\t d.Mixed Vegetable with chicken\n\t\t\t\t e.Mixed Vegetable with Shrimp\n");
    printf("\n\t\t\t\t 13. Mushroom section :- \n\n\t\t\t\t a.Garlic Mushroom\n\t\t\t\t b.Sauteed Mushroom\n\t\t\t\t c.creamy sauteed Mushroom\n\t\t\t\t d.Stoffed Mushroom\n\t\t\t\t e.Teriyaki Mushroom\n\t\t\t\t f.Fried Mushroom\n");
    printf("\n\t\t\t\t 14. Fries section :- \n\n\t\t\t\t a.French Fries\n\t\t\t\t b.Wedges\n\t\t\t\t c.Truffle Fries\n\t\t\t\t d.Peri Peri Fries\n ");
    printf("\n\t\t\t\t 15. Burger and Sub section :-\n\n\t\t\t\t a.Chicken cheese Burger\n\t\t\t\t b.Chicken Cheddar Burger\n\t\t\t\t c.Giganto Beef Burger \n\t\t\t\t d.Beef Burger\n\t\t\t\t e.Chicken Cheese Blast\n");
    printf("\n\t\t\t\t 16. Pizza section :- \n\n\t\t\t\t a.Typical Vegetarian\n\t\t\t\t b.Meaty Mushroom \n\t\t\t\t c.Chicken Alfredo\n\t\t\t\t d.4 Cheese\n\t\t\t\t e.Tuna\n ");
    printf("\n\t\t\t\t 17. Pasta section :- \n\n\t\t\t\t a.Chicken Backed Pasta\n\t\t\t\t b.Italian Pasta\n\t\t\t\t c.Giganto Beef Burger \n\t\t\t\t d.Beef Burger\n\t\t\t\t e.Chicken Cheese Blast\n ");
    printf("\n\t\t\t\t 18. Spaghetti section :-\n\n\t\t\t\t a.Spaghetti with meat sauce\n\t\t\t\t b.Spaghetti with grawned beef\n\t\t\t\t c.Spaghetti in creamy tomato sauce\n\t\t\t\t d.Vegetable Spaghetti \n\t\t\t\t e. Mushroom and garlic Spaghetti \n ");
    printf("\n\t\t\t\t 19. Noodles section :- \n\n\t\t\t\t a.Egg Noddles\n\t\t\t\t b.Chicken Noodles\n\t\t\t\t c.Vegetable chinese Noodles\n\t\t\t\t d.Hakka Noodles\n\t\t\t\t e.Beef Masala Showmain\n ");
    printf("\n\t\t\t\t 20. Sandwich section :-\n\n\t\t\t\t a.Veg Sandwich\n\t\t\t\t b.Mayonnaise Sandwich\n\t\t\t\t c.Bombay Grilled Sandwich\n\t\t\t\t d.Cheese Sandwich\n\t\t\t\t e.Stromboli Sandwich\n ");
    printf("\n\t\t\t\t 21. Sub section :- \n\n\t\t\t\t a.Chicken cheese Wrap\n\t\t\t\t b.Subway Melt\n\t\t\t\t c.Steak and Cheese Subway \n\t\t\t\t d.Roasted Chicken Subway\n\t\t\t\t e.Chicken Teriyaki Subway\n ");
    printf("\n\t\t\t\t 22. Fruite Salad section :- \n\n\t\t\t\t a.Mixed fruite Salad\n\t\t\t\t b.Lime Honey Fruite Salad\n\t\t\t\t c.Crunchi Peanut Butter Apple dip\n\t\t\t\t d.Honey yogurd Berry Salad\n\t\t\t\t e.Strawberry Tomato Salad\n ");
    printf("\n\t\t\t\t 23. Desert item Section :- ");
    printf("\n\t\t\t\t 24. Cake :- \n\n\t\t\t\t a.Vanilla Cake\n\t\t\t\t b.Chocolate Cake\n\t\t\t\t c.Red valvet Cake \n\t\t\t\t d.Chocolate Lava Cake\n\t\t\t\t e.Orange Cake\n");
    printf("\n\t\t\t\t 25. pastry and brownie section :-\n\n\t\t\t\t a.Chocolate pastry\n\t\t\t\t b.Chocolate brownie with Chocolate sauce\n\t\t\t\t c.Choco Chips \n\t\t\t\t d.Black Forest Cake\n\t\t\t\t e.Choux pastry\n ");
    printf("\n\t\t\t\t 26. Bakery :- \n\n\t\t\t\t a.Croissant\n\t\t\t\t b.Macaron\n\t\t\t\t c.Marshmalo \n\t\t\t\t d.Filo\n\t\t\t\t e.Cannoli\n ");
    printf("\n\t\t\t\t 27. Pie :- \n\n\t\t\t\t a.Apple Pie\n\t\t\t\t b.Pumpkin Pie\n\t\t\t\t c.Blue Berry Pie \n\t\t\t\t d.Cherry Pie\n\t\t\t\t e.Sweet potato \n ");
    printf("\n\t\t\t\t 28. Custard :- \n\n\t\t\t\t a.Banana Custard\n\t\t\t\t b.Fruite Custard\n\t\t\t\t c.Caramel Custard \n\t\t\t\t d.Egg custard\n\t\t\t\t e.Get well Custard\n ");
    printf("\n\t\t\t\t 29. Phrini :- \n\n\t\t\t\t a.Kesher Phirni\n\t\t\t\t b.Pista Phirni\n\t\t\t\t c.Mango phirni\n\t\t\t\t d.Rice Phirni\n\t\t\t\t e.Apple phirni\n\t\t\t\t f.Shahi tukra\n ");
    printf("\n\t\t\t\t 30. Pudding :- \n\n\t\t\t\t a.Bread pudding \n\t\t\t\t b.Creamy chocolate pudding\n\t\t\t\t c.Banana Puddding\n\t\t\t\t d.Chocolate pudding\n ");
    printf("\n\t\t\t\t 31. waffle :-\n\n\t\t\t\t a.Belgian Nutella Nut Waffle\n\t\t\t\t b.Seasonal Fresh Fruite Waffle\n\t\t\t\t c.Choco peanut Butter waffle\n  ");
    printf("\n\t\t\t\t 32. Drinks :-\n\n\t\t\t\t a.Ice Tea\n\t\t\t\t b.Lemonade\n\t\t\t\t c.Coca Cola\n\t\t\t\t d.Merinda\n\t\t\t\t e.Pepsi\n ");
    printf("\n\t\t\t\t 33. Sweet :- \n\n\t\t\t\t a.Shahi tukra\n\t\t\t\t b.Rosho golla\n\t\t\t\t c.Laddu\n\t\t\t\t d.Gelo\n\t\t\t\t e. Brownie\n ");
    printf("\n\t\t\t\t 34. Sauce :- \n\n\t\t\t\t a.Tomato Sauce\n\t\t\t\t b.Chili Sauce\n\t\t\t\t c.Mayo Sauce\n\t\t\t\t d.BBQ Sauce\n\t\t\t\t e.sweet and naga mixed sauce\n ");


}
void dinner()
{
    printf("\n\n\n\t\t\t\t Menu for DINNER : \n");
    printf("\t\t\t      ^^^^^^^^^^^^^^^^^^^^^^ \n");
    printf("\n\t\t\t\t 1. Salad section :- \n\n\t\t\t\t a.Green Salad\n\t\t\t\t b.Vegatbale salad \n\t\t\t\t c.Creamy vegan Pasta Salad\n\t\t\t\t d.Green Chicken Salad\n\t\t\t\t e.Cashew nut salad \n");
    printf("\n\t\t\t\t 2. Soup section :- \n\n\t\t\t\t a.Thai soup \n\t\t\t\t b.Corn soup \n\t\t\t\t c.Sea Food Soup\n\t\t\t\t d.Meaty Soup\n\t\t\t\t e.Cream and mushroom \n");
    printf("\n\t\t\t\t 3. Sides :- \n\n\t\t\t\t a.Wonton \n\t\t\t\t b.French fries \n\t\t\t\t c.Chicken fingers\n\t\t\t\t d.Mashed Potato\n\t\t\t\t e.Sweet Corn\n\t\t\t\t f.Nuggets\n\t\t\t\t g.Sausage \n\t\t\t\t h.Fish Cutlet\n\t\t\t\t i.Chicken Cutlet\n\t\t\t\t j.Colslaw \n");
    printf("\n\t\t\t\t 4. Rice section :- \n\n\t\t\t\t a.Fried rice with Chicken \n\t\t\t\t b.Beef Biriyani \n\t\t\t\t c.Mutton Kacchi \n\t\t\t\t d.Chicken Biriyani \n\t\t\t\t e.Khichuri \n\t\t\t\t f.Plain Rice \n\t\t\t\t g.Fried Rice With Sea Food\n\t\t\t\t.Steamed Rice \n");
    printf("\n\t\t\t\t 5. Naan section :-\n\n\t\t\t\t a.Normal Naan \n\t\t\t\t b.Garlic Butter Naan\n\t\t\t\t c.Keema Naan\n\t\t\t\t d.Spicy Naan\n\t\t\t\t e.Rumali Ruti\n");
    printf("\n\t\t\t\t 6. Chicken section :- \n\n\t\t\t\t a.Chicken Fry \n\t\t\t\t b.Chili Chicken\n\t\t\t\t c.Butter Chicken\n\t\t\t\t d.Chicken Green Curry\n\t\t\t\t e.Chicken Tikka Masala\n\t\t\t\t f.Cashew Chicken \n\t\t\t\t g.Teriyaki Chicken\n\t\t\t\t h.Hunters Chicken\n\t\t\t\t i. Peri Peri Chicken \n\t\t\t\t j. Sweet and Chilli Chicken Curry\n\t\t\t\t k.Munchurian\n");
    printf("\n\t\t\t\t 7. Beef section :- \n\n\t\t\t\t a.Kala Bhuna \n\t\t\t\t b.Beef Curry\n\t\t\t\t c.Beef Hatkora\n\t\t\t\t d.Bulgogi\n\t\t\t\t e.Meat loaf \n\t\t\t\t f.Stuff Beef\n\t\t\t\t g.Creamed Chipped Beef\n\t\t\t\t h.Roast Beef\n");
    printf("\n\t\t\t\t 8. Fish section :-\n\n\t\t\t\t a.Prawn Curry \n\t\t\t\t b.Lemon paper fish\n\t\t\t\t c.Prawn Malaikari\n\t\t\t\t d.Rupchanda Fry\n\t\t\t\t e.Smoked salmon\n\t\t\t\t f.Shorshe Ilish\n\t\t\t\t g.Rui dopiaza\n");
    printf("\n\t\t\t\t 9. Kabab and grill section :- \n\n\t\t\t\ta.Reshmi Chicken Kabab\n\t\t\t\t b.Chicken Chap\n\t\t\t\t c.Beef Boti Kabab\n\t\t\t\t d.Charcol Grill Kabab\n\t\t\t\t e.Doner Kabab\n\t\t\t\t f.Bufflo Kabab\n\t\t\t\t g.Shish Kabab\n\t\t\t\t h.Turkish Kabab\n\t\t\t\t i.Halal Kabab \n\t\t\t\t j.Bihari Kabab\n\t\t\t\t k.Chicken Tikka Kabab\n\t\t\t\t l.Tandoori Kabab\n");
    printf("\n\t\t\t\t 11. Steak section :- \n\n\t\t\t\t a.Chicken Steak\n\t\t\t\t b.Brisket\n\t\t\t\t c.Ribeye\n\t\t\t\t d.Lamb Grill\n\t\t\t\t e.Beef Steak\n\t\t\t\t g.T- Bone steak\n");
    printf("\n\t\t\t\t 12. Vegetable section :-\n\n\t\t\t\t a.Sauteed Vegetable\n\t\t\t\t b.Stir Fry Vegetable\n\t\t\t\t c.chinese Mixed Vegetable\n\t\t\t\t d.Mixed Vegetable with chicken\n\t\t\t\t e. Indian Masala Vegetable\n\t\t\t\t f.Mixed Vegetable with Shrimp\n");
    printf("\n\t\t\t\t 13. Mushroom section :- \n\n\t\t\t\t a.Garlic Mushroom\n\t\t\t\t b.Sauteed Mushroom\n\t\t\t\t c.creamy sauteed Mushroom\n\t\t\t\t d.Stoffed Mushroom\n\t\t\t\t e.Teriyaki Mushroom\n\t\t\t\t f.Creamy Mushroom\n\t\t\t\t g.Fried Mushroom\n");
    printf("\n\t\t\t\t 14. Fries section :- \n\n\t\t\t\t a.French Fries\n\t\t\t\t b.Wedges\n\t\t\t\t c.Truffle Fries\n\t\t\t\t d.Masala Alurdom\n\t\t\t\t e.Peri Peri Fries\n ");
    printf("\n\t\t\t\t 15. Burger and Sub section :-\n\n\t\t\t\t a.Chicken cheese Burger\n\t\t\t\t b.Chicken Cheddar Burger\n\t\t\t\t c.Giganto Beef Burger \n\t\t\t\t d.Beef Burger\n\t\t\t\t e.Chicken Subway\n\t\t\t\t f.BBQ Chicken Subway\n\t\t\t\t g.Beef Masala Subway\n\t\t\t\t i.Chicken Cheese Blast\n");
    printf("\n\t\t\t\t 16. Pizza section :- \n\n\t\t\t\t a.Typical Vegetarian\n\t\t\t\t b.Meaty Mushroom \n\t\t\t\t c.Chicken Alfredo\n\t\t\t\t d.4 Cheese\n\t\t\t\t e.Extra Cheesy pizza\n\t\t\t\t f.Tuna\n ");
    printf("\n\t\t\t\t 17. Pasta section :- \n\n\t\t\t\t a.Chicken Backed Pasta\n\t\t\t\t b.Italian Pasta\n\t\t\t\t c.Giganto Beef Burger \n\t\t\t\t d.Beef Burger\n\t\t\t\t e.Chicken Cheese Blast\n ");

    printf("\n\t\t\t\t 18. Spaghetti section :-\n\n\t\t\t\t a.Spaghetti with meat sauce\n\t\t\t\t b.Spaghetti with grawned beef\n\t\t\t\t c.Spaghetti in creamy tomato sauce\n\t\t\t\t d.Vegetable Spaghetti \n\t\t\t\t e. Mushroom and garlic Spaghetti \n ");
    printf("\n\t\t\t\t 19. Noodles section :- \n\n\t\t\t\t a.Egg Noddles\n\t\t\t\t b.Chicken Noodles\n\t\t\t\t c.Vegetable chinese Noodles\n\t\t\t\t d.Hakka Noodles\n\t\t\t\t e.Beef Masala Showmain\n ");
    printf("\n\t\t\t\t 20. Sandwich section :-\n\n\t\t\t\t a.Veg Sandwich\n\t\t\t\t b.Mayonnaise Sandwich\n\t\t\t\t c.Bombay Grilled Sandwich\n\t\t\t\t d.Cheese Sandwich\n\t\t\t\t e.Stromboli Sandwich\n ");
    printf("\n\t\t\t\t 21. Sub section :- \n\n\t\t\t\t a.Chicken cheese Wrap\n\t\t\t\t b.Subway Melt\n\t\t\t\t c.Steak and Cheese Subway \n\t\t\t\t d.Roasted Chicken Subway\n\t\t\t\t e.Chicken Teriyaki Subway\n ");
    printf("\n\t\t\t\t 22. Fruite Salad section :- \n\n\t\t\t\t a.Mixed fruite Salad\n\t\t\t\t b.Lime Honey Fruite Salad\n\t\t\t\t c.Crunchi Peanut Butter Apple dip\n\t\t\t\t d.Honey yogurd Berry Salad\n\t\t\t\t e.Strawberry Tomato Salad\n ");
    printf("\n\t\t\t\t 23. Desert item Section :- ");
    printf("\n\t\t\t\t 24. Cake :- \n\n\t\t\t\t a.Vanilla Cake\n\t\t\t\t b.Chocolate Cake\n\t\t\t\t c.Red valvet Cake \n\t\t\t\t d.Chocolate Lava Cake\n\t\t\t\t e.Orange Cake\n");
    printf("\n\t\t\t\t 25. pastry and brownie section :-\n\n\t\t\t\t a.Chocolate pastry\n\t\t\t\t b.Chocolate brownie with Chocolate sauce\n\t\t\t\t c.Choco Chips \n\t\t\t\t d.Black Forest Cake\n\t\t\t\t e.Choux pastry\n ");
    printf("\n\t\t\t\t 26. Bakery :- \n\n\t\t\t\t a.Croissant\n\t\t\t\t b.Macaron\n\t\t\t\t c.Marshmalo \n\t\t\t\t d.Filo\n\t\t\t\t e.Cannoli\n ");
    printf("\n\t\t\t\t 27. Pie :- \n\n\t\t\t\t a.Apple Pie\n\t\t\t\t b.Pumpkin Pie\n\t\t\t\t c.Blue Berry Pie \n\t\t\t\t d.Cherry Pie\n\t\t\t\t e.Sweet potato \n ");
    printf("\n\t\t\t\t 28. Custard :- \n\n\t\t\t\t a.Banana Custard\n\t\t\t\t b.Fruite Custard\n\t\t\t\t c.Caramel Custard \n\t\t\t\t d.Egg custard\n\t\t\t\t e.Get well Custard\n ");
    printf("\n\t\t\t\t 29. Phrini :- \n\n\t\t\t\t a.Kesher Phirni\n\t\t\t\t b.Pista Phirni\n\t\t\t\t c.Mango phirni\n\t\t\t\t d.Rice Phirni\n\t\t\t\t e.Apple phirni\n\t\t\t\t f.Shahi tukra\n ");
    printf("\n\t\t\t\t 30. Pudding :- \n\n\t\t\t\t a.Bread pudding \n\t\t\t\t b.Creamy chocolate pudding\n\t\t\t\t c.Banana Puddding\n\t\t\t\t d.Chocolate pudding\n ");
    printf("\n\t\t\t\t 31. waffle :-\n\n\t\t\t\t a.Belgian Nutella Nut Waffle\n\t\t\t\t b.Seasonal Fresh Fruite Waffle\n\t\t\t\t c.Choco peanut Butter waffle\n  ");
    printf("\n\t\t\t\t 32. Drinks :-\n\n\t\t\t\t a.Ice Tea\n\t\t\t\t b.Lemonade\n\t\t\t\t c.Coca Cola\n\t\t\t\t d.Merinda\n\t\t\t\t e.Pepsi\n ");
    printf("\n\t\t\t\t 33. Sweet :- \n\n\t\t\t\t a.Shahi tukra\n\t\t\t\t b.Rosho golla\n\t\t\t\t c.Laddu\n\t\t\t\t d.Gelo\n\t\t\t\t e. Brownie\n ");
    printf("\n\t\t\t\t 34. Sauce :- \n\n\t\t\t\t a.Tomato Sauce\n\t\t\t\t b.Chili Sauce\n\t\t\t\t c.Mayo Sauce\n\t\t\t\t d.BBQ Sauce\n\t\t\t\t e.sweet and naga mixed sauce\n ");


}

struct node* createadmin(struct node *head,int data, char foodname[1000], float price)
{
    newnode = (struct node*)malloc(sizeof(struct node));
    newnode->data = data;
    newnode->price = price;
    newnode-> quantity = 0;
    strcpy(newnode->foodname,foodname);
    newnode->next = NULL;
    newnode->prev = NULL;
    struct node *temp = head;
    if(temp==NULL)
        heada = taila = newnode;
    else
    {
        while(temp->next!=NULL)
        temp=temp->next;
        temp->next=newnode;
        newnode->prev = taila;
        taila = newnode;
    }

    return heada;
}

struct node* createcustomer(struct node *head,int data,int quantity)
{
    newnode = (struct node*)malloc(sizeof(struct node));

    struct node *temp1 = heada;
    int flag = 0;
    while(temp1!=NULL)
    {
        if(temp1->data==data)
        {
            flag = 1;
            break;
        }
        temp1 = temp1->next;
    }

    if(flag==1)
    {
        newnode->data = data;
        //newnode->price = quantity*(temp1->price);
        newnode-> quantity = quantity;
        strcpy(newnode->foodname,temp1->foodname);
        newnode->next = NULL;
        newnode->prev = NULL;

        struct node *temp = head;

        if(temp==NULL)
            headc = tailc = newnode;
        else
        {
            while(temp->next!=NULL)
                temp=temp->next;

            temp->next=newnode;
            newnode->prev = tailc;
            tailc = newnode;
        }


    }
    else
    {
        printf("\n\t\t\t\t\t\t\tThis item is not present in the menu!\n");
    }
    return headc;
}

void displayList(struct node *head)
{
    struct node *temp1 = head;
    if(temp1==NULL)
    {
        printf("\n\t\t\t\t\t\t\t\tList is empty!!\n\n");
    }
    else
    {
        printf("\n");
        while(temp1!=NULL)
        {
            if(temp1->quantity==0)
                printf("\t\t\t\t\t\t\t%d\t%s\t%0.2f\n",temp1->data,temp1->foodname,temp1->price);
            else
            {
                printf("\t\t\t\t\t\t\t%d\t%s\t%d\t%0.2f\n",temp1->data,temp1->foodname,temp1->quantity,temp1->price);
            }

            temp1 = temp1->next;
        }
        printf("\n");
    }

}

void reservation()
{
    printf("\n\t1. Lunch \n");
    printf("\t2. Dinner \n");
    printf("\t   Enter Your Choice --->");
}

struct node* delete(int data,struct node *head, struct node* tail)
{
    if(head==NULL)
    {
        printf("\n\t\t\t\t\t\t\tList is empty\n");
    }
    else
    {
        struct node* temp;
        if(data==head->data)
        {
            temp = head;
            head = head->next;
            if (head != NULL)
                head->prev = NULL;
            free(temp);
        }
        else if(data==tail->data)
        {
            temp = tail;
            tail = tail->prev;
            tail->next = NULL;
            free(temp);
        }
        else
        {
            temp = head;
            while(data!=temp->data)
            {
                temp = temp->next;
            }
            (temp->prev)->next = temp->next;
            (temp->next)->prev = temp->prev;
            free(temp);
        }
    }
    return head;
}

int deleteadmin()
{
    printf("\n\t\t\t\t\tEnter serial no. of the food item which is to be deleted: ");
    int num;
    scanf("%d",&num);

    struct node* temp=heada;
    while(temp!=NULL)
    {
        if (temp->data == num)
        {
            heada = delete(num, heada, taila);
            return 1;
        }
        temp=temp->next;
    }

    return 0;
}


struct node* deleteList(struct node* head)
{
    if(head==NULL)
    {
        return NULL;
    }
    else
    {
        struct node* temp = head;
        while(temp->next!=0)
        {
            temp = temp->next;
            free(temp->prev);
        }
        free(temp);
        head = NULL;
    }

    return head;
}

void admin()
{
    printf("\n\t\t\t\t\t\t          -----------------\n");
    printf("\t\t\t\t\t\t\t    ADMIN SECTION\n");
    printf("\t\t\t\t\t\t\t -------------------\n");
    while(1)
    {
        adminmenu();

        int opt;
        scanf("%d",&opt);

        if(opt==5)
            break;

        switch (opt)
        {
        case 1:
             displayList(head_s);
             break;
        case 2:

            printf("\n\t\t\t\t\t\t\tEnter serial no. of the food item: ");
            int num,flag = 0;
            char name[50];
            float price;
            scanf("%d",&num);

            struct node *temp = heada;

            while(temp!=NULL)
            {
                if(temp->data==num)
                {
                    printf("\n\t\t\t\t\t\tFood item with given serial number already exists!!\n\n");
                    flag = 1;
                    break;
                }
                temp = temp->next;
            }

            if(flag==1)
                break;

            printf("\t\t\t\t\t\t\tEnter food item name: ");
            scanf("%s",name);
            printf("\t\t\t\t\t\t\tEnter price: ");
            scanf("%f",&price);
            heada = createadmin(heada, num, name, price);
            printf("\n\t\t\t\t\t\t\tNew food item added to the list!!\n\n");
            break;
        case 3:
            if(deleteadmin())
            {
                printf("\n\t\t\t\t\t\t### Updated list of food items menu ###\n");
                displayList(heada);
            }
            else
                printf("\n\t\t\t\t\t\tFood item with given serial number doesn't exist!\n\n");

            break;
         case 4:
             printf("\n\t\t\t\t\t\t\t   ### Order menu ###\n");
             displayList(heada);
             break;

        default:
            printf("\n\t\t\t\t\t\tWrong Input !! PLease choose valid option\n");
            break;
        }
    }
}

int customer()
{
    int flag=0,j=1,x,n;
    char ch;
    printf("\n\t\t\t\t\t\t        ------------------\n");
    printf("\t\t\t\t\t\t\t CUSTOMER SECTION\n");
    printf("\t\t\t\t\t\t    -------------------------\n");
    while(1)
    {
        customermenu();

        int n;


        printf("\t\t\t\t\t\t\t Enter Your Choice --->  ");
        scanf("%d",&n);
        switch(n)
        {
        case 1:
            system("cls");
            reservation();
            scanf("%d",&n);
            printf("How many seat do you want? ");
            scanf("%d",&x);
            switch (n)
            {
            case 1:
                system("cls");

                int lunchp=(1500*x);
                int bill2=lunchp;
                system("cls");
                printf("Your total bill is %d\n",bill2);



                break;
                case 2:
               system("cls");
                int dinnerp=(2500*x);
                int bill3=dinnerp;
                system("cls");
                 printf("Your total bill is %d\n",bill3);
              break;
            }

            break;
        case 2:
            system("cls");
            printf("Menu for: \n 1.LUNCH \n");
            printf(" 2.DINNER \n");
            printf("Press 1 for lunch and 2 for dinner");
            scanf("%d",&n);
            switch(n)
            {
            case 1:
                system("cls");
                lunch();
                break;
                 case 2:
                     system("cls");
                     dinner();
                     break;

            }
            break;
       case 3:
            printf("\n\t\t\t\t\t\t\t  ### List of new items  ###\n");
            displayList(heada);
            break;
            case 4:
            printf("\n\t\t\t\t\t\t\t We are sorry for the inconvenience.Write your concern here.   \n\n\n");
            break;
        case 5:
            main();
            break;


        default:
            printf("\n\t\t\t\t\t\tWrong Input !! PLease choose valid option\n");
            break;

        }
        if(flag==1)
            break;
    }
    return 0;
}

void mainnenu()
{
    printf("\n\t\t\t\t\t   *******************************************\n");
    printf("\t\t\t\t\t      WELCOME TO BUFFET MANAGEMENT SYSTEM\n");
    printf("\t\t\t\t\t   *******************************************\n\n\n");
    printf("\t\t\t\t\t\t\t1. ADMIN SECTION--> \n");
    printf("\t\t\t\t\t\t\t2. CUSTOMER SECTION--> \n");
    printf("\t\t\t\t\t\t\t3. Exit--> \n\n");
    printf("\t\t\t\t\t\t\t   Enter Your Choice --->  ");
}

int main()
{
    system("cls");
    heada = createadmin(heada,1,"Lunch menu",5000);
    heada = createadmin(heada,2,"Dinner menu",7500);


    while(1)
    {
        mainnenu();
        int choice;
        scanf("%d",&choice);

        if(choice==3)
        {
            printf("\n\n\t\t\t\t\t\t\t**********Thank you!!**********\n");
            break;
        }

        switch (choice)
        {
        case 1:
            admin();
            break;
        case 2:
            customer();
            break;
        case 3:
            break;

        default:
            printf("\n\t\t\t\t\t\tWrong Input !! PLease choose valid option\n");
            break;
        }
    }
}

